package com.cg.service;

import java.util.List;

import com.cg.model.Customers;

public interface ICustomerService {
  public Customers findCustomerById1(int id);

public List<Customers> getAll();

public Customers findCustomerById(int customerId);
}
