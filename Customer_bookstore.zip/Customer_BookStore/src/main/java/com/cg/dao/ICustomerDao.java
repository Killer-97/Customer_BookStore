package com.cg.dao;

import java.util.List;

import org.hibernate.Session;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

import com.cg.model.Customers;


@Repository("iCustomerDao")
public interface ICustomerDao extends JpaRepository<Customers, Integer> {


	public Customers findByCustomerId(int customerId);
	
	List<Customers> findAll();
}
